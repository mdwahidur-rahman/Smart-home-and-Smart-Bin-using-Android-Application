package com.example.wahidtuhin.physicisthome;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

public class smartHome extends AppCompatActivity {

    Button btnBack, btnDis, btnf1, btnf2, btnR1, btnR2, btnR3, btnT;
    TextView outputapp, outputapp1, tempT, flame;
    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;
    InputStream inputStream;
    Thread thread;
    byte buffer[];
    int bufferPosition;
    boolean stopThread;

    //SPP UUID. Look for it
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        Intent newint = getIntent();
        address = newint.getStringExtra(pairedDevice.EXTRA_ADDRESS); //receive the address of the bluetooth device

        //view of the ledControl
        setContentView(R.layout.activity_smart_home);

        //outputapp = (TextView) findViewById(R.id.output);
        tempT = (TextView) findViewById(R.id.temperatureT);
        flame = (TextView) findViewById(R.id.flame);
        btnBack = (Button) findViewById(R.id.button2);
        btnDis = (Button) findViewById(R.id.button4);
        btnf1 = (Button) findViewById(R.id.f1);
        btnf2 = (Button) findViewById(R.id.f2) ;
        btnR1 = (Button) findViewById(R.id.bed1);
        btnR2 = (Button) findViewById(R.id.drawing);
        btnR3 = (Button) findViewById(R.id.kitchen);
        btnT = (Button) findViewById(R.id.temperature);


        final int[] a = {1};
        btnf1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(a[0] == 1)
                {
                    fan1One();
                    a[0] = 0;
                }
                else
                {
                    fan1Off();
                    a[0] = 1;
                }
            }
        });
        final int[] b = {1};
        btnf2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(b[0] == 1)
                {
                    fan2One();
                    b[0] = 0;
                }
                else
                {
                    fan2Off();
                    b[0] = 1;
                }
            }
        });
        final int[] c = {1};
        btnR1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(c[0] == 1)
                {
                    bedOne();;
                    c[0] = 0;
                }
                else
                {
                    bedOff();
                    c[0] = 1;
                }
            }
        });
        final int[] d = {1};
        btnR2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(d[0] == 1)
                {
                    drawingOne();
                    d[0] = 0;
                }
                else
                {
                    drawingOff();
                    d[0] = 1;
                }
            }
        });
        final int[] e = {1};
        btnR3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(e[0] == 1)
                {
                    kitchenOne();
                    e[0] = 0;
                }
                else
                {
                    kitchenOff();
                    e[0] = 1;
                }
            }
        });

        final int[] f = {1};
        btnT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(f[0] == 1)
                {
                    tempT.setText(" ");
                    tempOne();
                    beginListenForData1();
                    f[0] =0;
                }
                else
                {
                    tempOff();
                    tempT.clearComposingText();
                    tempT.setText("Not Available!!");
                    f[0] =1;
                }

            }
        });





        new ConnectBT().execute(); //Call the class to connect
        //flame();

        //inputsream

        //end

        //commands to be sent to bluetooth


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(smartHome.this, main.class);
                Disconnect();
                startActivity(i);
            }
        });

        btnDis.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(smartHome.this, pairedDevice.class);
                Disconnect();
                startActivity(i);
            }
        });


    }

    private void Disconnect()
    {
        if (btSocket!=null) //If the btSocket is busy
        {
            try
            {
                btSocket.close(); //close connection
            }
            catch (IOException e)
            { msg("Error");}
        }
        finish(); //return to the first layout

    }

    private void tempOne()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("TN".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void tempOff()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("TF".toString().getBytes());

            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }
    private void fan1One()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("FN".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void fan1Off()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("FF".toString().getBytes());

            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }
    private void fan2One()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("AN".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void fan2Off()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("AF".toString().getBytes());

            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }
    private void bedOne()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("BN".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void bedOff()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("BF".toString().getBytes());

            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }
    private void drawingOne()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("DN".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void drawingOff()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("DF".toString().getBytes());

            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }
    private void kitchenOne()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("KN".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void kitchenOff()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("KF".toString().getBytes());

            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }
    // fast way to call Toast
    private void msg(String s)
    {
        Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
    }



    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(smartHome.this, "Processing!!", "Please wait");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
            try
            {
                if (btSocket == null || !isBtConnected)
                {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();//start connection
                }
            }
            catch (IOException e)
            {
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);

            if (!ConnectSuccess)
            {
                msg("Lost the connection! Try again!");
                finish();
            }
            else
            {
                msg("Connection Establishment Succeded");
                isBtConnected = true;

                if(isBtConnected = true)
                {
                    try {
                        inputStream = btSocket.getInputStream();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    beginListenForData();
                }
            }
            progress.dismiss();
        }
    }

    void beginListenForData()
    {
        final Handler handler = new Handler();
        stopThread = false;
        buffer = new byte[1024];
        Thread thread  = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopThread)
                {
                    try
                    {
                        int byteCount = inputStream.available();
                        if(byteCount > 0)
                        {
                            byte[] rawBytes = new byte[byteCount];
                            inputStream.read(rawBytes);
                            final String string=new String(rawBytes,"UTF-8");
                            handler.post(new Runnable() {
                                public void run()
                                {

                                }
                            });

                        }
                    }
                    catch (IOException ex)
                    {
                        stopThread = true;
                    }
                }
            }
        });

        thread.start();
    }
    void beginListenForData1()
    {
        final Handler handler = new Handler();
        stopThread = false;
        buffer = new byte[1024];
        Thread thread  = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopThread)
                {
                    try
                    {
                        int byteCount = inputStream.available();
                        if(byteCount > 0)
                        {
                            byte[] rawBytes = new byte[byteCount];
                            inputStream.read(rawBytes);
                            final String string=new String(rawBytes,"UTF-8");
                            handler.post(new Runnable() {
                                public void run()
                                {
                                    tempT.append(string);

                                }
                            });

                        }
                    }
                    catch (IOException ex)
                    {
                        stopThread = true;
                    }
                }
            }
        });

        thread.start();
    }
    void flame()
    {
        final Handler handler = new Handler();
        stopThread = false;
        buffer = new byte[1024];
        Thread thread  = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopThread)
                {
                    try
                    {
                        int byteCount = inputStream.available();
                        if(byteCount > 0)
                        {
                            byte[] rawBytes = new byte[byteCount];
                            inputStream.read(rawBytes);
                            final String string=new String(rawBytes,"UTF-8");
                            handler.post(new Runnable() {
                                public void run()
                                {
                                    String F = "F";
                                    if(F.equals(string))
                                    {
                                        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            v.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
                                        } else {
                                            //deprecated in API 26
                                            v.vibrate(500);
                                        }
                                        flame.setText("Fire!!! Fire!!!");
                                    }
                                    else
                                    {
                                        flame.setText("Please, Press the following buttons to control\nButtons");
                                    }

                                }
                            });

                        }
                    }
                    catch (IOException ex)
                    {
                        stopThread = true;
                    }
                }
            }
        });

        thread.start();
    }
}



