package com.example.wahidtuhin.physicisthome;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

public class trashBox extends AppCompatActivity {

    Button btnBack, btnDis;
    TextView outputapp, outputapp1;
    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;
    InputStream inputStream;
    Thread thread;
    byte buffer[];
    int bufferPosition;
    boolean stopThread;

    //SPP UUID. Look for it
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        Intent newint = getIntent();
        address = newint.getStringExtra(pairedDevice.EXTRA_ADDRESS); //receive the address of the bluetooth device

        //view of the ledControl
        setContentView(R.layout.activity_trash_box);

        outputapp1 = (TextView) findViewById(R.id.outp);
        btnBack = (Button) findViewById(R.id.t1);
        btnDis = (Button) findViewById(R.id.t2);



        new ConnectBT().execute(); //Call the class to connect

        //inputsream

        //end

        //commands to be sent to bluetooth


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(trashBox.this, main.class);
                Disconnect();
                startActivity(i);
            }
        });

        btnDis.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(trashBox.this, pairedDevice.class);
                Disconnect();
                startActivity(i);
            }
        });

    }

    private void Disconnect()
    {
        if (btSocket!=null) //If the btSocket is busy
        {
            try
            {
                btSocket.close(); //close connection
            }
            catch (IOException e)
            { msg("Error");}
        }
        finish(); //return to the first layout

    }

    // fast way to call Toast
    private void msg(String s)
    {
        Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
    }



    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(trashBox.this, "Processing!!", "Please wait");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
            try
            {
                if (btSocket == null || !isBtConnected)
                {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();//start connection
                }
            }
            catch (IOException e)
            {
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);

            if (!ConnectSuccess)
            {
                msg("Lost the connection! Try again!");
                finish();
            }
            else
            {
                msg("Connection Establishment Succeded");
                isBtConnected = true;

                if(isBtConnected = true)
                {
                    try {
                        inputStream = btSocket.getInputStream();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    beginListenForData();
                }
            }
            progress.dismiss();
        }
    }

    void beginListenForData()
    {
        final Handler handler = new Handler();
        stopThread = false;
        buffer = new byte[1024];
        Thread thread  = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopThread)
                {
                    try
                    {
                        int byteCount = inputStream.available();
                        if(byteCount > 0)
                        {
                            byte[] rawBytes = new byte[byteCount];
                            inputStream.read(rawBytes);
                            final String string=new String(rawBytes,"UTF-8");
                            handler.post(new Runnable() {
                                public void run()
                                {
                                    String a="a",b="a",c="c",d="d",e="e",f="f",g="g",h="h",i="i",j="j";
                                    if(a.equals(string))
                                    {
                                        outputapp1.setText("Almost 100% empty");
                                        outputapp1.setTextColor(Color.parseColor("#80ff00"));
                                    }
                                    else if(b.equals(string))
                                    {
                                        outputapp1.setText("Almost 90% empty");
                                        outputapp1.setTextColor(Color.parseColor("#00ff40"));
                                    }
                                    else if(c.equals(string))
                                    {
                                        outputapp1.setText("Almost 80% empty");
                                        outputapp1.setTextColor(Color.parseColor("#00ff80"));
                                    }
                                    else if(d.equals(string))
                                    {
                                        outputapp1.setText("Almost 70% empty");
                                        outputapp1.setTextColor(Color.parseColor("#bfff00"));
                                    }
                                    else if(e.equals(string))
                                    {
                                        outputapp1.setText("Almost 60% empty");
                                        outputapp1.setTextColor(Color.parseColor("#ffff00"));
                                    }
                                    else if(f.equals(string))
                                    {
                                        outputapp1.setText("Almost 50% empty");
                                        outputapp1.setTextColor(Color.parseColor("#ffbf00"));
                                    }
                                    else if(g.equals(string))
                                    {
                                        outputapp1.setText("Almost 30% empty");
                                        outputapp1.setTextColor(Color.parseColor("#00ff80"));
                                    }
                                    else if(h.equals(string))
                                    {
                                        outputapp1.setText("Almost 20% empty");
                                        outputapp1.setTextColor(Color.parseColor("#00ff80"));
                                    }
                                    else if(i.equals(string))
                                    {
                                        outputapp1.setText("Almost 10% empty");
                                        outputapp1.setTextColor(Color.parseColor("#ff4000"));
                                    }
                                    else if(j.equals(string))
                                    {
                                        outputapp1.setText("Below 10% empty");
                                        outputapp1.setTextColor(Color.parseColor("#ff0000"));
                                    }
                                }
                            });

                        }
                    }
                    catch (IOException ex)
                    {
                        stopThread = true;
                    }
                }
            }
        });

        thread.start();
    }
}
