package com.example.wahidtuhin.physicisthome;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class main extends AppCompatActivity {

    Button connect_btn1, connect_btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        connect_btn1 = (Button) findViewById(R.id.connect1);
        connect_btn2 = (Button) findViewById(R.id.connect2);

        connect_btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(main.this, pairedDevice.class);
                startActivity(i);
            }
        });
        connect_btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(main.this, pairedDevice1.class);
                startActivity(i);
            }
        });

    }
}
